const { Console } = require('console');
const http = require("http")
const fs = require('fs/promises')
const pug = require("pug");
const path = require('path');
const os = require('node:os');
const port = 3000;
const host = 'localhost'
const compiledFunction = pug.compileFile('index.pug');

const server = http.createServer(async (req, res) => {
    res.setHeader('Conetent-type', 'text/html')
    res.end(compiledFunction({
        CPUS: JSON.stringify(os.cpus()),
        FreeMem: `${os.freemem()} byte`,
        OSVersion: os.version()        
    }))

})

const exp = 'Server is running <script>console.log(dir)</script>'


server.listen(port, host, () => {
    console.log(`Server is running: http://${host}:${port}`)
})