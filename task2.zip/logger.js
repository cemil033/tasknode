const { Console } = require('console');
const fs = require('fs')

const info = fs.createWriteStream('./info.log');

const errorlog = fs.createWriteStream('./error.log')


const logger = new Console({stderr: errorlog, stdout: info})

module.exports = {logger}