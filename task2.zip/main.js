const http=require("http")
const url=require("url")
const { logger } = require('./logger');
const users=[
    {username:"cemil33",age:27,name:"Cemil",surname:"Ibrahimov"},
    {username:"cemil34",age:28,name:"Cemil1",surname:"Ibrahimov1"},
    {username:"cemil35",age:29,name:"Cemil2",surname:"Ibrahimov2"}
]
http.createServer((req,res)=>{   
    var {pathname} = url.parse(req.url)
if (pathname !== "/favicon.ico") {
    const myUrl=new URL(req.headers.host+req.url) 
    console.log(myUrl);
    console.log(pathname)
    console.log(myUrl.searchParams)
    var  un  = myUrl.searchParams.get('un')
    console.log(un)

  if(pathname=="/status"){
        users.forEach(e=>{
            if(e.username==un){
                res.statusCode=200;    
                res.setHeader('Content-Type', 'text/plain');
                res.end(`username:${e.username} Name:${e.name} surname:${e.surname} age:${e.age}`) 
                logger.info(`username:${e.username} Name:${e.name} surname:${e.surname} age:${e.age}`)
            }
        })
        res.statusCode=200;    
        res.setHeader('Content-Type', 'text/plain');
        logger.error("unknown")
        res.end("unknown")   
  }
  else{
      res.statusCode = 200;
      res.setHeader('Content-Type', 'text/plain');
      res.end('Hello World');
    }  
}
}).listen(3001,'localhost',()=>{
    console.log(`http://localhost:3001`)
})